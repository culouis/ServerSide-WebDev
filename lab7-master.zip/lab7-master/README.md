# practice
# this project contains many errors
# if you fix all errors you should have a index page that displays this NAV
# Lab 7 then 
